from django.test import SimpleTestCase
from django.urls import reverse, resolve
from main.views import homepage, CategoryList, PolicyList , CustomerList, PolicyRecordList, register_request


#radi mićila

class TestUrls(SimpleTestCase):

    def test_homepage_url_is_resolved(self):
        url = reverse('main:index')
        print(resolve(url))

        self.assertEquals(resolve(url).func, homepage)

    def test_category_url_is_resolved(self):
        url = reverse('main:category')

        self.assertEquals(resolve(url).func.view_class, CategoryList)

    def test_customer_url_is_resolved(self):
        url = reverse('main:customer')

        self.assertEquals(resolve(url).func.view_class, CustomerList)

    def test_policy_url_is_resolved(self):
        url = reverse('main:policy')

        self.assertEquals(resolve(url).func.view_class, PolicyList)
    def test_policyrecord_url_is_resolved(self):
        url = reverse('main:policyrecord')

        self.assertEquals(resolve(url).func.view_class, PolicyRecordList)
