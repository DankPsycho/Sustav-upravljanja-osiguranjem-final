from django.test import TestCase, Client
from django.urls import reverse
from main.models import Category, Policy, PolicyRecord, Customer

class TestViews(TestCase):

    def setUp(self):
        self.client = Client()
        self.register = reverse('main:register')
        self.index = reverse('main:index')
        self.category = reverse('main:category')
        self.customer = reverse('main:customer')
        self.policy = reverse('main:policy')
        self.policyrecord = reverse('main:policyrecord')
        

        self.category1 = Category.objects.create(
            category_name = 'TestName',
        )

    def test_project_index_GET(self):
        client = Client()

        response = client.get(self.index)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'index.html')

    def test_project_category_GET(self):
        client = Client()

        response = client.get(self.category)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'main/category_list.html')
    
    def test_project_policy_GET(self):
        client = Client()

        response = client.get(self.policy)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'main/policy_list.html')

    def test_project_customer_GET(self):
        client = Client()

        response = client.get(self.customer)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'main/customer_list.html')

    def test_project_policyrecord_GET(self):
        client = Client()

        response = client.get(self.policyrecord)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'main/policyrecord_list.html')


    def test_project_register_GET(self):
        client = Client()

        response = client.get(self.register)
        self.assertEquals(response.status_code, 200)

