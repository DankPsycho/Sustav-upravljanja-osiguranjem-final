from django.test import TestCase
from main.models import Customer, Category , Policy

#jedini test koji radi atm


class Testmodels(TestCase):

    def setUp(self):
        self.category1 = Category.objects.create(
            category_name = 'Biciklo',
        )
        self.policy1 = Policy.objects.create(
            sum_assurance = '20',
            premium = '40',
            tenure = '25',
        )
        
        self.customer1 = Customer.objects.create(
            name = 'Pero',
            address = 'Vinogradska 15',
            city = 'Ljubescica',
            country = 'Poljska',
        )


    def test_models(self):
        self.assertEquals(self.category1.category_name, "Biciklo")
        self.assertEquals(self.policy1.sum_assurance, "20")
        self.assertEquals(self.policy1.tenure, "25")
        self.assertEquals(self.customer1.name, "Pero")
        self.assertEquals(self.customer1.city, "Ljubescica")
