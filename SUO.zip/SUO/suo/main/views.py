from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.views.generic import ListView
from main.models import Customer, Category , Policy , PolicyRecord
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import  render, redirect
from .forms import NewUserForm
from django.contrib.auth import login
from django.contrib import messages
from .forms import *

from django.http import HttpResponse, HttpResponseRedirect
from django.db.models import Q
from django.core.management import call_command



## Create your views here.


def homepage(request):
    return render(request, "index.html")

class CustomerList(ListView):
    model = Customer

class CategoryList(ListView):
    model = Category

class PolicyList(ListView):
    model = Policy

class PolicyRecordList(ListView):
    model = PolicyRecord

def register_request(request):
	if request.method == "POST":
		form = NewUserForm(request.POST)
		if form.is_valid():
			user = form.save()
			login(request, user)
			messages.success(request, "Registration successful." )
			return redirect("main:homepage")
		messages.error(request, "Unsuccessful registration. Invalid information.")
	form = NewUserForm()
	return render (request=request, template_name="registration/register.html", context={"register_form":form})

def add_category(request):
    submitted = False
    if request.method == "POST":
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('?submitted=True')
    else:
        form = CategoryForm
        if 'submitted' in request.GET:
            submitted = True
    return render(request, 'main/add_category.html', {'form':form, 'submitted':submitted})

def add_policy(request):
    submitted = False
    if request.method == "POST":
        form = PolicyForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('?submitted=True')
    else:
        form = PolicyForm
        if 'submitted' in request.GET:
            submitted = True
    return render(request, 'main/add_policy.html', {'form':form, 'submitted':submitted})

def add_customer(request):
    submitted = False
    if request.method == "POST":
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('?submitted=True')
    else:
        form = CustomerForm
        if 'submitted' in request.GET:
            submitted = True
    return render(request, 'main/add_customer.html', {'form':form, 'submitted':submitted})

def update_customer(request, customer_id):
     customer = Customer.objects.get(id=customer_id)
     customer.name = "Milorad Milich"
     customer.save()




def customer_search(request):
    if request.method == 'GET':
        query = request.GET.get('q')
        if query:
            customers = Customer.objects.filter(
                models.Q(name__icontains=query) | models.Q(address__icontains=query)
            )
            return render(request, 'main/customer_search.html', {'customers': customers})
    return render(request, 'main/customer_search.html', {})



def policy_search(request):
    policies = Policy.objects.all()

    query = request.GET.get('q')
    if query:
        policies = policies.filter(policy_name__icontains=query)

    context = {
        'policies': policies,
        'query': query
    }
    return render(request, 'main/policy_search.html', context)

def generate_test_data(request):
    if request.method == 'POST':
        call_command('setup_test_data')

        return redirect(('main:index'))
    else:
        return render(request, 'main/index.html')

def delete_all_data(request):
    if request.method == 'POST':
        Customer.objects.all().delete()
        Category.objects.all().delete()
        Policy.objects.all().delete()
        PolicyRecord.objects.all().delete()
        return redirect('main:index')
    return render(request, 'main/delete_all_data.html')