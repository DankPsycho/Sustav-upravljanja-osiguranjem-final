from django.urls import path 
from . import views

from main.views import CustomerList , CategoryList , PolicyList , PolicyRecordList


app_name = 'main'  # here for namespacing of urls.

urlpatterns = [

    path('index/', views.homepage, name='index'),
    path('customer/', CustomerList.as_view(), name='customer'),
    path('category/', CategoryList.as_view(), name='category'),
    path('policyrecord/', PolicyRecordList.as_view(), name='policyrecord'),
    path('policy/', PolicyList.as_view(), name='policy'),
    path('register/', views.register_request, name='register'),
    path('add_category/', views.add_category, name='add_category'),
    path('add_customer/', views.add_customer, name='add_customer'),
    path('add_policy/', views.add_policy, name='add_policy'),
    path('customer_search/', views.customer_search, name='customer_search'),
    path('policy_search/', views.policy_search, name='policy_search'),
    path('delete_all_data/', views.delete_all_data, name='delete_all_data'),
    path('generate_test_data/', views.generate_test_data, name='generate_test_data'),
    

]
