# Sustav-upravljanja-osiguranjem

Zadatak: Sustav upravljanja osiguranjem za potrebe kolegija Programiranje za web.
Uradio: Vedran Štimac
Projekt sadrži
https://github.com/DankPsycho/Sustav-upravljanja-osiguranjem-finals
*
Django projekt i aplikaciju
Model koji sadrži barem 3 entiteta (unutar modela voditi računa različitim tipovima podataka)
Barem jednu one to one, one to many i many to many relaciju.
Generirane testne podatke
Prikaz generiranih podataka za svaki entitet u modelu pomoću generičkih pogleda
Unos novih vrijednosti u bazu
Prikaz i pretraga postojećih vrijednosti iz baze
*
# Sustav-upravljanja-osiguranjem
